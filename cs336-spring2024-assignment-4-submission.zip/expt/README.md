# expt

```bash
micromamba install -y -c conda-forge redis-server
```
